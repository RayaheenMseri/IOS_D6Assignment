//
//  userView.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//

import SwiftUI

class User: ObservableObject , Identifiable{
    var id: UUID = UUID()
    var name: String = ""
    var age: Int = 0
    var email: String = ""
    
    init(name: String, age: Int, email: String) {
        self.name = name
        self.age = age
        self.email = email
    }
}

