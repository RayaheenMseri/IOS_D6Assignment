//
//  AddUserView.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//

import SwiftUI

struct AddUserView: View {
    @Environment(\.dismiss) private var dismiss
    @State var name: String = ""
    @State var age: Int = 0
    @State var email: String = ""
    @StateObject private var viewModel = userListViewModel()
    
    var body: some View {
        Text("Add New User")
        
        Form {
            HStack{
                Text("Name :")
                TextField("Name", text: $name)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5)
            }
            HStack{
                Stepper("Age:", value: $age)
                    .cornerRadius(5)
                Text("\(age)")
            }
            HStack{
                Text("Email :")
                TextField("Email", text: $email)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5)
            }
            
            Button("Add"){
                
                    viewModel.addUser(user: User(name: name, age: age, email: email))
                
                dismiss()
            }.padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            .frame(width: .infinity, alignment: .center)
        }.scrollContentBackground(.hidden)
        
    }
}
