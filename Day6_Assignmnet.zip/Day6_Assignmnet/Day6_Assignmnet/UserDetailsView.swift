//
//  UserDetailsView.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//

import SwiftUI

struct UserDetailsView: View {
    @ObservedObject var details: User
    
    var body: some View {
        VStack{
            
            // user image
            Image(systemName: "person.fill")
                        .font(.system(size: 50))
                        .foregroundColor(.black)
                        .padding(.bottom)
           // user name
            HStack{
                Text("Name :")
                Text(details.name)
            }.frame(width: .infinity, alignment: .center)
            
            // user age
            HStack{
                Text("Age :")
                Text("\(details.age)")
            }.frame(width: .infinity, alignment: .center)
            
            // user Email
            HStack{
                Text("Email :")
                Text(details.email)
            }.frame(width: .infinity, alignment: .center)
        
        }
    }
}
