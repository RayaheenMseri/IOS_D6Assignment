//
//  ContentView.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//


//Task:
//       Create a SwiftUI app that:
//Displays a list of items using List.
//Implements custom cells with images and text.
//Includes NavigationStack to open a detail view when an item is selected.
//Adds an animation when adding/removing items.
//
//
//Task Requirements:
//SwiftUI List Implementation:
//✅ Use a List to display an array of items.
//✅ Customize the list cells with an image and text.
//Navigation & Data Flow:
//✅ Implement NavigationStack and NavigationLink.
//✅ Pass data to a detail screen.
//Animations & Interactions:
//✅ Add .animation() when inserting/deleting items.
//✅ Use .onTapGesture() to interact with the list.
//

import SwiftUI


struct ContentView: View {
    @StateObject private var viewModel = userListViewModel()  // Initialize the view model for managing users.

    var body: some View {
        NavigationStack {  // Use NavigationStack to manage navigation within the app.

            // Header for the list: Display the column names
            HStack {
                Text("#")
                    .font(.headline)
                    .frame(width: 100, alignment: .center)
                Spacer()
                Text("Name")
                    .font(.headline)
                    .frame(width: 250, alignment: .leading)
                Spacer()
            }
            .navigationTitle("Users")  // Set the title for the navigation bar
            .padding()
            
            // List of users displayed below the header
            List {
                // Loop through all users and display each one
                ForEach(viewModel.users) { user in
                    HStack {
                        // Display a system image (user icon)
                        Image(systemName: "person.fill")
                            .font(.system(size: 25))  // Set the size of the icon
                            .foregroundColor(.black)  // Set the icon color

                        // Display the user's name
                        Text(user.name)

                        // NavigationLink to show details of the selected user
                        NavigationLink {
                            UserDetailsView(details: user)  // Pass the selected user's details to UserDetailsView
                        } label: {
                            Text("")  // Empty text so that the navigation link itself is invisible
                        }
                    }
                }
                .onDelete(perform: delete)  // Swipe to delete users from the list
                .padding(.bottom, 5)
                
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    // Add button to add a new user
                    Image(systemName: "plus")
                        .onTapGesture {
                            // When the "plus" icon is tapped, a new user is added to the list with animation
                            withAnimation(.smooth) {
                                viewModel.addUser(user: User(name: "Rayaheen", age: 24, email: "Rayaheen@gamil.com"))
                            }
                        }
                }
            }
            .scrollContentBackground(.hidden)  // Hide the scroll background for a cleaner appearance
            
        }
    }
    
    // Function to delete users from the list
    func delete(at offsets: IndexSet) {
        withAnimation(.easeInOut) {  // Add animation to the deletion process
            viewModel.users.remove(atOffsets: offsets)  // Remove users at the specified offsets
        }
    }
}

#Preview {
    ContentView()
}
