//
//  Day6_AssignmnetApp.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//

import SwiftUI

@main
struct Day6_AssignmnetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
