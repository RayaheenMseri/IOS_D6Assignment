//
//  userListViewModel.swift
//  Day6_Assignmnet
//
//  Created by Taibah Valley Academy on 09/09/1446 AH.
//

import SwiftUI

class userListViewModel: ObservableObject {
    @Published var users: [User] = [
        User(name: "Mohammad Ali", age : 25, email: "2BIG@gmail.com"),
        User(name: "Ali Alhaider", age: 20, email: "ali@gmail.com"),
        User(name: "Othman Alhaider", age: 22, email: "othman@gmail.com"),
        User(name: "Salem Alhaider", age: 24, email: "salem@gmail.com"),
        User(name: "Yaser Alhaider", age: 21, email: "yaser@gmail.com"),
    ]
    
    func addUser(user: User) {
        users.append(user)
    }

}
